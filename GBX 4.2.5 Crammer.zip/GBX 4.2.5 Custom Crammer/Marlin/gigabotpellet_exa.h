// gigabotpellet_exa.h
//
// This include file is intended to isolate configuration settings for Marlin by 
// separating them into sections
//

#include "gigabotpellet.h"

#undef MSG_GIGABOT3
#define MSG_GIGABOT3 "Exabot X"

#if SYSTEM_SECTION == INFO
  #undef  STRING_CONFIG_H_AUTHOR
  #define STRING_CONFIG_H_AUTHOR "(GBX EXA V4.2.5)"

  #undef  SHOW_CUSTOM_BOOTSCREEN
  #define SHOW_CUSTOM_BOOTSCREEN
#endif

#if SYSTEM_SECTION == SUBSECTION(TEMPERATURE, 2)
  #if ENABLED(NOZZLE_PARK_FEATURE)
	#undef NOZZLE_PARK_POINT
    #define NOZZLE_PARK_POINT { (X_MIN_POS + 10), (Y_MIN_POS + 10), 20 }
  #endif
#endif

#if SYSTEM_SECTION == SUBSECTION(TEMPERATURE, 3)
  #undef  TEMP_HYSTERESIS

  #define TEMP_HYSTERESIS 4       // (degC) range of +/- temperatures considered "close" to the target one

  #undef  WATCH_BED_TEMP_PERIOD
  #define WATCH_BED_TEMP_PERIOD 600            // was 200 Seconds
 #endif

#if SYSTEM_SECTION == SUBSECTION(TEMPERATURE, 1)
  #undef  BED_MAXTEMP
  #define BED_MAXTEMP      135

  #if ENABLED(PIDTEMP)
    #undef  DEFAULT_Kp
    #undef  DEFAULT_Ki
    #undef  DEFAULT_Kd

    // Gigabot 3 (24 volts) 
    #define DEFAULT_Kp 30.38
    #define DEFAULT_Ki  0.91
    #define DEFAULT_Kd 250.09
  #endif
//#define PIDTEMPBED
  #if ENABLED(PIDTEMPBED)
    #undef  DEFAULT_bedKp
    #undef  DEFAULT_bedKi
    #undef  DEFAULT_bedKd

    #define DEFAULT_bedKp 10.00
    #define DEFAULT_bedKi 0.023
    #define DEFAULT_bedKd 304.50
  #endif
#endif

#if SYSTEM_SECTION == SUBSECTION(MACHINE, 4)
  #undef  INVERT_X_DIR
  #undef  INVERT_Y_DIR

  #define INVERT_X_DIR true
  #define INVERT_Y_DIR true
#endif



#if SYSTEM_SECTION == SUBSECTION(HOMING, 2)
  #undef Y_HOME_DIR
  #define Y_HOME_DIR -1
#endif 

#if SYSTEM_SECTION == SUBSECTION(MACHINE, 5)
  #undef  X_BED_SIZE
  #undef  Y_BED_SIZE
  #undef  Z_MAX_POS
  #undef  X_MIN_POS
  #undef  Y_MIN_POS

  #define X_BED_SIZE   780
  #define Y_BED_SIZE   780
  #define Z_MAX_POS    1600
  #define X_MIN_POS    -87
  #define Y_MIN_POS    -60
#endif

#if SYSTEM_SECTION == SUBSECTION(HOMING, 3)
  #undef MANUAL_X_HOME_POS 
  #undef MANUAL_Y_HOME_POS
  
  #define MANUAL_X_HOME_POS X_MIN_POS
  #define MANUAL_Y_HOME_POS Y_MIN_POS
#endif 

#if SYSTEM_SECTION == SUBSECTION(EXTRAS, 3)
  #undef  Y_DUAL_STEPPER_DRIVERS
  #undef  Z_DUAL_STEPPER_DRIVERS

  #define Y_DUAL_STEPPER_DRIVERS
  #define Z_DUAL_STEPPER_DRIVERS 
  #define Y_DUAL_ENDSTOPS       
  #define Y2_USE_ENDSTOP       

  #if ENABLED(Y_DUAL_STEPPER_DRIVERS)
  #undef INVERT_Y2_VS_Y_DIR
    #define INVERT_Y2_VS_Y_DIR true   // Set 'true' if Y motors should rotate in opposite directions
    #define Y_DUAL_ENDSTOPS
    #if ENABLED(Y_DUAL_ENDSTOPS)
      #define Y2_USE_ENDSTOP _YMAX_
      #define Y_DUAL_ENDSTOPS_ADJUSTMENT  0
    #endif
  #endif
#endif

#if SYSTEM_SECTION == SUBSECTION(MOTION, 1)
  #undef  DEFAULT_AXIS_STEPS_PER_UNIT
  #undef  DEFAULT_MAX_FEEDRATE
  #undef  DEFAULT_MAX_ACCELERATION
  #undef  DEFAULT_ACCELERATION
  #undef  DEFAULT_RETRACT_ACCELERATION
  #undef  DEFAULT_XJERK
  #undef  DEFAULT_YJERK

  #define DEFAULT_AXIS_STEPS_PER_UNIT   { 66.667, 66.667, 95.613, 200 }
  #define DEFAULT_MAX_FEEDRATE          { 100, 100, 4, 500 }
  #define DEFAULT_MAX_ACCELERATION      { 1000, 1000, 25, 10000 }
  #define DEFAULT_ACCELERATION          1000    // X, Y, Z and E acceleration for printing moves
  #define DEFAULT_RETRACT_ACCELERATION  1500  
  #define DEFAULT_XJERK                 10.0
  #define DEFAULT_YJERK                 10.0
#endif

if SYSTEM_SECTION == SUBSECTION(TEMPERATURE, 4)
  #if ENABLED(THERMAL_PROTECTION_HOTENDS)
    #undef THERMAL_PROTECTION_PERIOD
    #undef THERMAL_PROTECTION_HYSTERESIS
    
    #define THERMAL_PROTECTION_PERIOD 360          // was 180 Seconds
    #define THERMAL_PROTECTION_HYSTERESIS 15      // Degrees Celsius
  #endif

  #if ENABLED(THERMAL_PROTECTION_BED)
    #undef THERMAL_PROTECTION_BED_PERIOD
    #undef THERMAL_PROTECTION_BED_HYSTERESIS
    
    #define THERMAL_PROTECTION_BED_PERIOD 600     // was 120 Seconds
    #define THERMAL_PROTECTION_BED_HYSTERESIS 15  // Degrees Celsius
  #endif
  
  #undef  TEMP_SENSOR_AD595_GAIN
  #define TEMP_SENSOR_AD595_GAIN 2.0

  #define TEMP_SENSOR_AD8495_OFFSET -250

  #undef  TEMP_SENSOR_AD8495_GAIN 
  #define TEMP_SENSOR_AD8495_GAIN 2.0 

  #define AD8495_FORMULA (5.0 * 100.0) / 1024.0 / (OVERSAMPLENR) * (TEMP_SENSOR_AD8495_GAIN) + TEMP_SENSOR_AD8495_OFFSET
#endif

#if SYSTEM_SECTION == SUBSECTION(EXTRAS, 4)
  #undef  DIGIPOT_I2C_NUM_CHANNELS
  #define DIGIPOT_I2C_NUM_CHANNELS    7 // AZTEEG_X3_PRO: 8 (Not sure why this was set to 7 at some point)
  #undef  DIGIPOT_I2C_MOTOR_CURRENTS
  #define DIGIPOT_I2C_MOTOR_CURRENTS  { 2.25, 2.25, 2.25, 2.3, 2.3, 1.8, 1.8 }  //  AZTEEG_X3_PRO
#endif
